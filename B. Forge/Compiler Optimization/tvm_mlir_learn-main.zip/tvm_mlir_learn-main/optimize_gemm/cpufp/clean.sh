rm *.o cpufp cpuid_x86 gen.sh
