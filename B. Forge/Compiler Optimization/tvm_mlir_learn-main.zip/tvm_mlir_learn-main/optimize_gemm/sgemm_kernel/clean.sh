rm *.o sk_asm sk_its naive.* tuned.*
